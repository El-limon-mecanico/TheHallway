Components ={"Prueba"}

Prueba = {
    valor1 = 1,
    valor2 = 3,
    valor3 = "Quack"
}